$(document).ready(function(){
    // marque effect
    $('.marquee').marquee();
    // wow include
    var wowAction = new WOW().init();
});